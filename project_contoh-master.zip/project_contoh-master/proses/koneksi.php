<?php
$connect = mysqli_connect("localhost", "root", "123", "pondok_it");
?>